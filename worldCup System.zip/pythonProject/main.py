from itertools import combinations
from prettytable import PrettyTable

class Team:
    def __init__(self, name):
        self.name = name
        self.points = 0
        self.goals_for = 0
        self.goals_against = 0
        self.goal_difference = 0
        self.stage_goals = {'round16': 0, 'quarter_finals': 0, 'semi_finals': 0, 'finals': 0}

    def update_score(self, goals_for, goals_against, stage=None):
        self.goals_for += goals_for
        self.goals_against += goals_against
        self.goal_difference = self.goals_for - self.goals_against
        if stage:
            self.stage_goals[stage] += goals_for
        if goals_for > goals_against:
            self.points += 3
        elif goals_for == goals_against:
            self.points += 1

class Group:
    def __init__(self, name, teams):
        self.name = name
        self.teams = teams

    def play(self, team1, team2, goals1, goals2):
        team1.update_score(goals1, goals2)
        team2.update_score(goals2, goals1)

    def get_table(self):
        self.teams.sort(key=lambda x: (-x.points, x.goal_difference, x.goals_for))
        table = PrettyTable(['Rank', 'Team', 'Points', 'GF', 'GA', '+/-'])
        for i, team in enumerate(self.teams, start=1):
            table.add_row([i, team.name, team.points, team.goals_for, team.goals_against, team.goal_difference])
        print(f'Group {self.name}:\n{table}')

def set_scores(group):
    for team1, team2 in combinations(group.teams, 2):
        while True:
            try:
                print(f'{team1.name} vs {team2.name}:')
                goals1, goals2 = map(int, input('Score (e.g., 3-1): ').split('-'))
                group.play(team1, team2, goals1, goals2)
                break
            except ValueError:
                print('Invalid score. Please enter a valid score in the format "3-1".')

def play_match(team1, team2, stage):
    while True:
        try:
            print(f'{team1.name} vs {team2.name}:')
            goals1, goals2 = map(int, input('Score: ').split('-'))
            if goals1 != goals2:
                team1.update_score(goals1, goals2, stage)
                team2.update_score(goals2, goals1, stage)
                return team1 if goals1 > goals2 else team2
            else:
                print("No Draws allowed")
        except ValueError:
            print('Invalid score format.')

def create_teams():
    return [
        Team('Netherlands'), Team('Qatar'), Team('Ecuador'), Team('Senegal'),
        Team('England'), Team('USA'), Team('Iran'), Team('Wales'),
        Team('Argentina'), Team('Poland'), Team('Mexico'), Team('Saudi Arabia'),
        Team('France'), Team('Australia'), Team('Tunisia'), Team('Denmark'),
        Team('Japan'), Team('Spain'), Team('Germany'), Team('Costa Rica'),
        Team('Morocco'), Team('Croatia'), Team('Belgium'), Team('Canada'),
        Team('Brazil'), Team('Switzerland'), Team('Cameroon'), Team('Serbia'),
        Team('Portugal'), Team('South Korea'), Team('Uruguay'), Team('Ghana')
    ]

def create_groups(teams):
    group_names = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H']
    return {name: Group(name, teams[i*4:(i+1)*4]) for i, name in enumerate(group_names)}

def get_top_teams_from_groups(groups):
    top_teams = []
    for group in groups.values():
        # Sort the teams in the group based on points, goal difference, and goals for
        sorted_teams = sorted(group.teams, key=lambda x: (-x.points, x.goal_difference, x.goals_for))
        # Select the top two teams from each group
        top_teams.extend(sorted_teams[:2])
    return top_teams

def play_knockout_round(teams, stage):
    winners = []
    for i in range(0, len(teams), 2):
        winner = play_match(teams[i], teams[i+1], stage)
        winners.append(winner)
    return winners

def main():
    teams = create_teams()
    groups = create_groups(teams)

    print("\n--- Group Stage ---")
    for group in groups.values():
        set_scores(group)
        group.get_table()

    top_teams = get_top_teams_from_groups(groups)

    print("\n--- Round of 16 ---")
    round_of_16_winners = play_knockout_round(top_teams, 'round16')

    print("\n--- Quarterfinals ---")
    quarterfinal_winners = play_knockout_round(round_of_16_winners, 'quarter_finals')

    print("\n--- Semifinals ---")
    semifinal_winners = play_knockout_round(quarterfinal_winners, 'semi_finals')

    # Final
    final_winner = play_knockout_round(semifinal_winners, 'finals')[0]

    print(f"The winner of the tournament is {final_winner.name}.")

if __name__ == '__main__':
    main()